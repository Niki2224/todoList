module.exports = {
	Roboto: {
		normal: __dirname + '/Roboto/Roboto-Regular.ttf',
		bold: __dirname + '/Roboto/Roboto-Medium.ttf',
		italics: __dirname + '/Roboto/Roboto-Italic.ttf',
		bolditalics: __dirname + '/Roboto/Roboto-MediumItalic.ttf'
	}
};
